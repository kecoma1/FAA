El notebook se ha ejecutado y desarrollado en windows 10.
Añadir en este directorio el directorio "ConjuntosDatosP2Knn" con los archivos "pima-indians-diabetes.data" 
y "wdbc.data". Añadir en este directorio el directorio "ConjuntosDatosP2KMeans" con el archivo "nums.csv".

FAAP2_1462_10
	     |_ConjuntosDatosP2Knn
	     |	     		|_pima-indians-diabetes.data
	     |		     	|_wdbc.data
	     |
	     |
	     |_ConjuntosDatosP2KMeans
				|_nums.csv