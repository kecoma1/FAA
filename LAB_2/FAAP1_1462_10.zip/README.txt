El notebook se ha ejecutado y desarrollado en windows 10.
Añadir este directorio el directorio "ConjuntosDatos" con los archivos "german.data" y "tic-tac-toe.data".

FAAP1_1462_10
	     |_ConjuntosDatos
			     |_german.data
			     |_tic-tac-toe.data

