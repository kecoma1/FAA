from Datos import Datos
dataset=Datos('ConjuntosDatos/german.data')
print("DATOS:\n", dataset.datos, "\n")
print("NOMINAL ATRIBUTOS:\n", dataset.nominalAtributos, "\n")
print("DICCIONARIO:\n", dataset.diccionario, "\n")